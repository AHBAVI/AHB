-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 03, 2019 at 10:30 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `balance`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `did` int(100) NOT NULL,
  `type_name` varchar(150) NOT NULL,
  `data_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`did`, `type_name`, `data_name`) VALUES
(6, 'ca', 'Cash'),
(7, 'nca', 'Land'),
(8, 'cl', 'Account payable'),
(9, 'ncl', 'Bonds payable'),
(10, 'eq', 'Owners investment'),
(11, 'ca', 'Cash equivalents'),
(12, 'ca', 'Short-term deposits'),
(13, 'ca', 'Stock'),
(14, 'ca', 'Marketable securities\r\n'),
(15, 'ca', 'Office supplie'),
(16, 'nca', 'Machinery'),
(17, 'nca', 'Building'),
(18, 'nca', 'fixed deposit'),
(19, 'nca', 'Furniture'),
(20, 'nca', 'Trademarks'),
(21, 'nca', 'Patents'),
(22, 'nca', 'Equipment'),
(23, 'cl', 'Bills payable\r\n'),
(24, 'cl', 'Income taxes payable\r\n'),
(25, 'cl', 'Interest payable\r\n'),
(26, 'cl', 'Bank account overdrafts\r\n'),
(27, 'cl', 'Accrued expenses\r\n'),
(28, 'cl', 'Short-term loans'),
(29, 'ncl', 'Long-term notes payable\r\n'),
(30, 'ncl', 'Mortgage payable\r\n'),
(31, 'ncl', 'Deferred tax liabilities\r\n'),
(32, 'ncl', 'Capital lease'),
(33, 'eq', 'Retained earnings');

-- --------------------------------------------------------

--
-- Table structure for table `sheet`
--

CREATE TABLE `sheet` (
  `sid` int(200) NOT NULL,
  `uid` varchar(150) NOT NULL,
  `data` varchar(150) NOT NULL,
  `type` varchar(50) NOT NULL,
  `amount` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` int(100) NOT NULL,
  `type` varchar(150) NOT NULL,
  `lname` varchar(150) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `type`, `lname`, `status`) VALUES
(1, 'nca', 'Non-current assets', 1),
(2, 'ca', 'current assets', 1),
(3, 'ncl', 'Non-current liabilities', 1),
(4, 'cl', 'current liabilities', 1),
(5, 'eq', 'Equity', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(100) NOT NULL,
  `uname` varchar(150) NOT NULL,
  `time` varchar(100) NOT NULL,
  `fstatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `sheet`
--
ALTER TABLE `sheet`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `did` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `sheet`
--
ALTER TABLE `sheet`
  MODIFY `sid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
