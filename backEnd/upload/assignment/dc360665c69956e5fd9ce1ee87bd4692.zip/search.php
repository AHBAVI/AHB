<?php
include('conman.php');
if (isset($_REQUEST['stl'])) 
{
	$stl = $_REQUEST['stl'];
	$cat = $_REQUEST['cat'];

	if ($cat=="all") {
	
		if (strlen($stl)>=2) 
		{
		//echo 'serch_text-'.$stl;
			$sql = mysqli_query($conn,"SELECT * FROM data WHERE data_name LIKE '%$stl%'");
			if (mysqli_num_rows($sql)>0) 
			{
			
				while ($row = mysqli_fetch_array($sql)) 
				{
					$title = $row['data_name'];
					echo '
					<option class="live" value="'.$title.'" onclick="slive(this.value)" style="padding: 10px;">
					'.$title.'<br>
					</option>
					';
				}

			}
			else
			{
				echo '<option class="live" style="padding: 10px;">
					No Suggested:(
					</option>';
			}
		}
	}
}
if (isset($_REQUEST['uname'])) {
	$uname = $_REQUEST['uname'];
	date_default_timezone_set("Asia/Colombo");
    $current = date("Y-m-d-h-i-sa");
	//echo $uname;
	$sql = mysqli_query($conn,"INSERT INTO user VALUES('','$uname','$current','0')");
}
if (isset($_REQUEST['data'])) {
	$data = $_REQUEST['data'];
	$amount = $_REQUEST['amount'];
	$uname = $_REQUEST['unamel'];
	$available = mysqli_query($conn,"SELECT * FROM data WHERE data_name='$data'");
	if (mysqli_num_rows($available)>0) {
		$type = mysqli_query($conn,"SELECT * FROM data WHERE data_name='$data'");
		while ($rdata = mysqli_fetch_array($type)) {
			$types = $rdata['type_name'];
		}
		//echo $uname;
		//echo $data;
		$sql = mysqli_query($conn,"INSERT INTO sheet VALUES('','$uname','$data','$types','$amount')");
		$gd = mysqli_query($conn,"SELECT * FROM sheet WHERE uid='$uname'");
		if (mysqli_num_rows($gd)>0) {
			while ($row = mysqli_fetch_array($gd)) {

				echo '
					<li id="rec">'.$row['data'].'-<span style="margin-left:10px">'.$row['amount'].'</span>  
	        		<span class="close" onclick="delr('.$row['sid'].')">&times;</span></li>
				';
			}
			echo '<a href="action.php?uname='.$uname.'"><button type="button" style="margin-top:10px" value="'.$uname.'">Generate Balance Sheet</button></a>';
		}
	}else{
		echo '
		<div class="alertf">
		  <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span> 
		  <strong>Data not in system.please select result from search list</strong>
		</div>
		';
	}

}
if (isset($_REQUEST['delr'])) {
	$id = $_REQUEST['delr'];
	$sql = mysqli_query($conn,"SELECT * FROM sheet WHERE sid='$id'");
	while ($row = mysqli_fetch_array($sql)) {
		$uname = $row['uid'];
	}

	mysqli_query($conn,"DELETE FROM sheet WHERE sid='$id'");
	$gd = mysqli_query($conn,"SELECT * FROM sheet WHERE uid='$uname'");
	if (mysqli_num_rows($gd)>0) {
		while ($row = mysqli_fetch_array($gd)) {

			echo '
				<li id="rec">'.$row['data'].'-<span style="margin-left:10px">'.$row['amount'].'</span>  
        		<span class="close" onclick="delr('.$row['sid'].')">&times;</span></li>
			';
		}
		if (mysqli_num_rows($gd)>0) {
			echo '<a href="action.php?uname='.$uname.'"><button type="button" style="margin-top:10px" value="'.$uname.'">Generate Balance Sheet</button></a>';
		}
	}
}

if (isset($_REQUEST['gid'])) {
	$uname = $_REQUEST['gid'];


	/*assets*/
  		echo '
	<table id="customers">
	  <tr>
	    <th>Assets</th>
	    <th style="text-align: right;">Amount</th>
	  </tr>
  		';
  		$nca = 0;
  		$sqlnca = mysqli_query($conn,"SELECT * FROM sheet WHERE type='nca' AND uid='$uname'");
  		if (mysqli_num_rows($sqlnca)>0) {
  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Non-current assets</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlnca)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $nca = $nca + $row['amount']; 			
	  		}
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total non-current assets</td>
			    <td style="color: #31708f;background-color: #d9edf7;" class="righ">'.$nca.'</td>
			  </tr>';
		}

  		$ca = 0;
  		$sqlca = mysqli_query($conn,"SELECT * FROM sheet WHERE type='ca' AND uid='$uname'");

  		if (mysqli_num_rows($sqlca)) {
  		
	  		echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Current assets</td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlca)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $ca = $ca + $row['amount']; 			
	  		}
	  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total current assets</td>
			    <td style="color: #31708f;background-color: #d9edf7;" class="righ">'.$ca.'</td>
			  </tr>';
		} 
		$tot = $nca+$ca; 
		echo'
		  <tr>
		  	<td style="background-color: #ff9800;"><b>Total assets</b></td>
		  	<td style="background-color: #ff9800;" class="righ"><b>'.$tot.'</b></td>
		  </tr>
		</table>
  		';
  
/*end assets*/

/*Liabilitie*/
  	echo '
	<table id="customers">
	  <tr>
	    <th>Liabilitie & Equity</th>
	    <th style="text-align: right;">Amount</th>
	  </tr>
  	';
  		$ncl = 0;
  		$sqlncl = mysqli_query($conn,"SELECT * FROM sheet WHERE type='ncl' AND uid='$uname'");
  		if (mysqli_num_rows($sqlncl)>0) {
  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Non-current liabilitie</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlncl)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $ncl = $ncl + $row['amount']; 			
	  		}
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total non-current liabilitie</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$ncl.'</td>
			  </tr>';
		}

  		$cl = 0;
  		$sqlcl = mysqli_query($conn,"SELECT * FROM sheet WHERE type='cl' AND uid='$uname'");

  		if (mysqli_num_rows($sqlcl)>0) {
  		
	 		echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Current liabilitie</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlcl)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $cl = $cl + $row['amount']; 			
	  		}
	  		$tot = $ncl+$cl;
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total current liabilitie</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$cl.'</td>
			  </tr>';
		}
		if (mysqli_num_rows($sqlcl)>0 OR mysqli_num_rows($sqlncl)>0) {
		
			echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">Total liabilitie</td>
			    <td class="righ">'.$tot.'</td>
			  </tr>';
		}

   		$eq = 0;
  		$sqleq = mysqli_query($conn,"SELECT * FROM sheet WHERE type='eq' AND uid='$uname'");

  		if (mysqli_num_rows($sqleq)>0) {
			echo'<tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Equity</td>
			    <td class="righ"></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqleq)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $eq = $eq + $row['amount']; 			
	  		}

	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">Total Equity</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$eq.'</td>
			  </tr>';
		}
		$tot = $ncl+$cl+$eq;
		echo '
		  <tr>
		    <td style="background-color: #ff9800;"><b>Total Liabilitie & Equity</b></td>
		    <td style="background-color: #ff9800;" class="righ"><b>'.$tot.'</b></td>
		  </tr>
		</table>
  		';




	$gd = mysqli_query($conn,"SELECT * FROM sheet WHERE uid='$uname'");
	if (mysqli_num_rows($gd)>0) {
		while ($row = mysqli_fetch_array($gd)) {

			echo '
				<li id="rec">'.$row['data'].'-<span style="margin-left:10px">'.$row['amount'].'</span>  
        		<span class="close" onclick="delr('.$row['sid'].')">&times;</span></li>
			';
		}
		if (mysqli_num_rows($gd)>0) {
			echo '<a href="action.php?uname='.$uname.'"><button type="button" style="margin-top:10px" value="'.$uname.'">Generate Balance Sheet</button></a>';
		}
	}
}

?>
