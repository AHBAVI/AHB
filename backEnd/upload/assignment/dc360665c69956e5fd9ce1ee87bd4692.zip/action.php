<?php
if (isset($_REQUEST['uname'])) {
	$uname = $_REQUEST['uname'];
}
include('conman.php');
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>BS | System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--blue star background-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Anton'>
  <link rel="stylesheet" href="css/style1.css">
  <!--end blue star-->

  <!-- hill background and start button-->
  <link rel="stylesheet" href="css/styleb1.css">
  <!-- end that-->

  <!--fade in out script-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!-- and fade-->

<script>
$(document).ready(function(){
  $(".btn1").click(function(){
    $(".btn1").fadeOut()
    $(".calform").fadeIn();
  });
  $(".nextBtn").click(function(){
    var uname = document.getElementById("uname").value;
    if (uname != "") {
      $(".calform").fadeOut()
      $(".data").fadeIn();
    }else{
      alert("Please fill out user name");
    }
  });
});
</script>
 <style>
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}
#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  min-width: 500px;
  width: 70%;
  min-width: 300px;
  border-top-right-radius: 100px;
  border-bottom-left-radius: 100px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  position: absolute;
  margin: 0;
  padding: 0;
  color: #f9f1e9;
  text-align: center;
  top: 35%;
  left: 50%;
  -webkit-transform: translate3d(-50%, -50%, 0);
  transform: translate3d(-50%, -50%, 0);
  opacity: 0.8;
  filter: alpha(opacity=60);
}

h1 {
  text-align: center;  
}


/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #429FFD;
  border-radius: 50px;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #429FFD;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
  border-top-right-radius: 100px;
  border-bottom-left-radius: 100px;
}

button:hover {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  border-top-right-radius: 100px;
  border-bottom-left-radius: 100px;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #429FFD;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
#mySidenav a {
  position: absolute;
  left: 0;
  transition: 0.3s;
  padding: 15px;
  width: 100px;
  text-decoration: none;
  font-size: 20px;
  color: white;
  border-radius: 0 5px 5px 0;
}

/*#mySidenav a:hover {
  left: 0;
}*/
#projects {
  top: 50px;
  background-color: #f44336;
}
.bcol{
  color: black;
}
form.example input[type=text] {
    padding: 12px;
    font-size: 17px;
    border: 2px solid #2196F3;
    float: left;
    width: 100%;
    background: #fff;
    /*border-top-left-radius:100px;
    border-bottom-left-radius:100px;*/
    box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
}
.amount{
  margin-top: 10px;
  width: 100%;
}
form.example button {
    float: left;
    width: 100%;
    padding: 11.2px;
    background: #2196F3;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none;
    cursor: pointer;
    border-radius:80px;
    margin-top: 10px;
    
}

form.example button:hover {
    background: #0b7dda;
    box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
}

form.example::after {
    content: "";
    clear: both;
    display: table;
}
.live:hover {
    background-color: #f1f1f1;

}
.uls {
  list-style-type: none;
  padding: 0;
  margin: 0;
  margin-top: 10px;
}

.uls li {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block;
  position: relative;
  border: 2px solid #2196F3;
  border-radius:10px;
  cursor: pointer;
}

.uls li:hover {
  background-color: #eee;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.close {
  cursor: pointer;
  position: absolute;
  top: 50%;
  right: 0%;
  padding: 12px 16px;
  transform: translate(0%, -50%);
}

.close:hover {background: #bbb;border-radius:9px;}

.alertf {
  padding: 8px;
  background-color: #f44336;
  color: white;
  border-radius:10px;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}
#customers td{
  color: #31708f;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #429FFD;
  color: white;
}
.righ{
  text-align: right;
}
</style> 
</head>
<script type="text/javascript" src="js/search.js"></script>
<body>

<!-- star background-->
<div class="night">
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
  <div class="shooting_star"></div>
</div>
<!-- end star background-->
<div id="regForm" id="data" class="data" style="margin-top: 200px">
<?php
	/*assets*/
  		echo '
	<table id="customers">
	  <tr>
	    <th>Assets</th>
	    <th style="text-align: right;">Amount</th>
	  </tr>
  		';
  		$nca = 0;
  		$sqlnca = mysqli_query($conn,"SELECT * FROM sheet WHERE type='nca' AND uid='$uname'");
  		if (mysqli_num_rows($sqlnca)>0) {
  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Non-current assets</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlnca)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $nca = $nca + $row['amount']; 			
	  		}
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total non-current assets</td>
			    <td style="color: #31708f;background-color: #d9edf7;" class="righ">'.$nca.'</td>
			  </tr>';
		}

  		$ca = 0;
  		$sqlca = mysqli_query($conn,"SELECT * FROM sheet WHERE type='ca' AND uid='$uname'");

  		if (mysqli_num_rows($sqlca)) {
  		
	  		echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Current assets</td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlca)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $ca = $ca + $row['amount']; 			
	  		}
	  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total current assets</td>
			    <td style="color: #31708f;background-color: #d9edf7;" class="righ">'.$ca.'</td>
			  </tr>';
		} 
		$tot = $nca+$ca; 
		echo'
		  <tr>
		  	<td style="background-color: #ff9800;"><b>Total assets</b></td>
		  	<td style="background-color: #ff9800;" class="righ"><b>'.$tot.'</b></td>
		  </tr>
		</table>
  		';
  
/*end assets*/

/*Liabilitie*/
  	echo '
	<table id="customers">
	  <tr>
	    <th>Liabilitie & Equity</th>
	    <th style="text-align: right;">Amount</th>
	  </tr>
  	';
  		$ncl = 0;
  		$sqlncl = mysqli_query($conn,"SELECT * FROM sheet WHERE type='ncl' AND uid='$uname'");
  		if (mysqli_num_rows($sqlncl)>0) {
  		
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Non-current liabilitie</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlncl)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $ncl = $ncl + $row['amount']; 			
	  		}
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total non-current liabilitie</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$ncl.'</td>
			  </tr>';
		}

  		$cl = 0;
  		$sqlcl = mysqli_query($conn,"SELECT * FROM sheet WHERE type='cl' AND uid='$uname'");

  		if (mysqli_num_rows($sqlcl)>0) {
  		
	 		echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Current liabilitie</td>
			    <td></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqlcl)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $cl = $cl + $row['amount']; 			
	  		}
	  		$tot = $ncl+$cl;
	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Total current liabilitie</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$cl.'</td>
			  </tr>';
		}
		if (mysqli_num_rows($sqlcl)>0 OR mysqli_num_rows($sqlncl)>0) {
		
			echo'
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">Total liabilitie</td>
			    <td class="righ">'.$tot.'</td>
			  </tr>';
		}

   		$eq = 0;
  		$sqleq = mysqli_query($conn,"SELECT * FROM sheet WHERE type='eq' AND uid='$uname'");

  		if (mysqli_num_rows($sqleq)>0) {
			echo'<tr>
			    <td style="color: #31708f;background-color: #d9edf7;">
			    Equity</td>
			    <td class="righ"></td>
			  </tr>
	  		';
	  		while ($row = mysqli_fetch_array($sqleq)) {
				echo'<td>'.$row['data'].'</td>
			    	 <td class="righ">'.$row['amount'].'</td></tr>';  
			    	 $eq = $eq + $row['amount']; 			
	  		}

	  		echo '
			  <tr>
			    <td style="color: #31708f;background-color: #d9edf7;">Total Equity</td>
			    <td class="righ" style="color: #31708f;background-color: #d9edf7;">'.$eq.'</td>
			  </tr>';
		}
		$tot = $ncl+$cl+$eq;
		echo '
		  <tr>
		    <td style="background-color: #ff9800;"><b>Total Liabilitie & Equity</b></td>
		    <td style="background-color: #ff9800;" class="righ"><b>'.$tot.'</b></td>
		  </tr>
		</table>
  		';
  		mysqli_query($conn,"DELETE FROM sheet WHERE uid='$uname'");
  		mysqli_query($conn,"DELETE FROM user WHERE uname='$uname'");

?>
</div>
    <script>
      function slive(str) {
        document.getElementById('search').value = str;
        document.getElementById('livesearch').style.display = "none";
      }
    </script>
  <!-- script for start button-->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/react/0.14.2/react.js'></script>
  <script  src="js/index.js"></script>
  <!-- end scripts for button-->

</body>

</html>