<?php
$conn = mysqli_connect('localhost','root','') or die("Connection Error : ".mysqli_error());
mysqli_select_db($conn,'balance') or die("DB Error : ".mysqli_error());
?>