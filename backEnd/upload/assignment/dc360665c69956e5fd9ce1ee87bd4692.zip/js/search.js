function searchlive(str) {
    //var ahb = document.getElementById('scat').value;
    var search = document.getElementById('search').value;
    document.getElementById('livesearch').style.display = "block";
    var fini = search+"&cat="+"all";
    if (str=="") { 
        document.getElementById("livesearch").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();

        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("livesearch").innerHTML = this.responseText;
                document.getElementById("livesearch").style.border="1px solid #A5ACB2";
            }
        };
        xmlhttp.open("GET","search.php?stl="+fini,true);
        xmlhttp.send();
    }
}
function auser(str){
    var uname = document.getElementById("uname").value;
    if (str=="") { 
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();

        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","search.php?uname="+uname,true);
        xmlhttp.send();
    }    
}
function add(str){
    var account = document.getElementById("search").value;
    var amount = document.getElementById("amount").value;
    var uname = document.getElementById("uname").value;
    var fini = account+"&amount="+amount+"&unamel="+uname;
    if (str=="") { 
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();

        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","search.php?data="+fini,true);
        xmlhttp.send();
    }  
}
function delr(str){
    if (str=="") { 
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();

        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","search.php?delr="+str,true);
        xmlhttp.send();
    } 
}
function genarate(str){
    if (str=="") { 
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();

        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("result").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","search.php?gid="+str,true);
        xmlhttp.send();
    } 
}

